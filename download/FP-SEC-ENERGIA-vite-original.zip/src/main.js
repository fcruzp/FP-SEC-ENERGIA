/**
 * main.js — Punto de entrada principal
 * Ensambla todos los componentes y módulos
 */

// ── Importar estilos globales ──
import './styles/main.css';

// ── Importar componentes HTML ──
import { renderMobileNav } from './components/MobileNav.js';
import { renderSiteHeader } from './components/SiteHeader.js';
import { renderHero } from './components/Hero.js';
import { renderAbout } from './components/About.js';
import { renderLeadership } from './components/Leadership.js';
import { renderAreas } from './components/Areas.js';
import { renderObservatory } from './components/Observatory.js';
import { renderNews } from './components/News.js';
import { renderDocuments } from './components/Documents.js';
import { renderEvents } from './components/Events.js';
import { renderMultimedia } from './components/Multimedia.js';
import { renderSubscribe } from './components/Subscribe.js';
import { renderSiteFooter } from './components/SiteFooter.js';

// ── Importar módulos de lógica ──
import { initHeader } from './scripts/header.js';
import { initThreeScene } from './scripts/threeScene.js';
import { initDonutChart } from './scripts/charts.js';
import { initAnimations, initSketchfabEmbed, initAboutSketchfab, initFilters } from './scripts/animations.js';

// ── Ensamblar el DOM ──
const app = document.getElementById('app');

app.innerHTML = `
  ${renderMobileNav()}
  ${renderSiteHeader()}
  ${renderHero()}
  ${renderAbout()}
  ${renderLeadership()}
  ${renderAreas()}
  ${renderObservatory()}
  ${renderNews()}
  ${renderDocuments()}
  ${renderEvents()}
  ${renderMultimedia()}
  ${renderSubscribe()}
  ${renderSiteFooter()}
`;

// ── Inicializar módulos ──
document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initThreeScene();
  initDonutChart();
  initAnimations();
  initSketchfabEmbed();
  initAboutSketchfab();
  initFilters();
});
