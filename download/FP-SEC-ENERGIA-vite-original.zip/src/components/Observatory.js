/**
 * Observatory — Dashboard con KPIs, gráficos de barras y donut chart
 */
export function renderObservatory() {
  return `
    <section id="observatory">
      <div class="section-inner">
        <div class="section-header fade-up">
          <div class="section-label">Panel de datos</div>
          <h2 class="section-title">Observatorio Energético</h2>
          <p class="section-desc">Monitoreo en tiempo real de los indicadores clave del sector eléctrico dominicano.</p>
        </div>
        <div class="obs-grid">
          <div class="kpi-card fade-up">
            <div class="kpi-header">
              <div class="kpi-icon">📉</div>
              <span class="kpi-badge down">↑ +2.3%</span>
            </div>
            <div class="kpi-val"><span class="counter" data-val="40.2">0</span>%</div>
            <div class="kpi-label">Pérdidas eléctricas</div>
            <div class="kpi-bar"><div class="kpi-bar-fill" data-pct="40"></div></div>
          </div>
          <div class="kpi-card featured fade-up">
            <div class="kpi-header">
              <div class="kpi-icon">🌱</div>
              <span class="kpi-badge up">↑ +6.1%</span>
            </div>
            <div class="kpi-val"><span class="counter" data-val="28.4">0</span>%</div>
            <div class="kpi-label">Generación renovable</div>
            <div class="kpi-bar"><div class="kpi-bar-fill" data-pct="28"></div></div>
          </div>
          <div class="kpi-card fade-up">
            <div class="kpi-header">
              <div class="kpi-icon">⚡</div>
              <span class="kpi-badge neu">→ Estable</span>
            </div>
            <div class="kpi-val"><span class="counter" data-val="3850">0</span> MW</div>
            <div class="kpi-label">Demanda energética (pico)</div>
            <div class="kpi-bar"><div class="kpi-bar-fill" data-pct="65"></div></div>
          </div>
          <div class="kpi-card fade-up">
            <div class="kpi-header">
              <div class="kpi-icon">💲</div>
              <span class="kpi-badge down">↑ +4.7%</span>
            </div>
            <div class="kpi-val">RD$<span class="counter" data-val="14.8">0</span></div>
            <div class="kpi-label">Costo promedio kWh</div>
            <div class="kpi-bar"><div class="kpi-bar-fill" data-pct="55"></div></div>
          </div>
          <div class="kpi-card fade-up">
            <div class="kpi-header">
              <div class="kpi-icon">🏭</div>
              <span class="kpi-badge up">↑ +3.2%</span>
            </div>
            <div class="kpi-val"><span class="counter" data-val="4218">0</span> MW</div>
            <div class="kpi-label">Capacidad instalada</div>
            <div class="kpi-bar"><div class="kpi-bar-fill" data-pct="72"></div></div>
          </div>
          <div class="kpi-card fade-up">
            <div class="kpi-header">
              <div class="kpi-icon">🏠</div>
              <span class="kpi-badge up">↑ +1.8%</span>
            </div>
            <div class="kpi-val"><span class="counter" data-val="87.3">0</span>%</div>
            <div class="kpi-label">Cobertura energética</div>
            <div class="kpi-bar"><div class="kpi-bar-fill" data-pct="87"></div></div>
          </div>
        </div>
        <div class="obs-bottom fade-up">
          <div class="chart-card">
            <h3>Generación por fuente (GWh) — 2024</h3>
            <div class="chart-bars" id="chart-bars">
              <div class="chart-bar-col"><div class="chart-bar" style="height:0" data-h="85%" title="Térmica: 8,200 GWh"></div><div class="chart-bar-lbl">Térmica</div></div>
              <div class="chart-bar-col"><div class="chart-bar alt" style="height:0" data-h="30%" title="Solar: 2,900 GWh"></div><div class="chart-bar-lbl">Solar</div></div>
              <div class="chart-bar-col"><div class="chart-bar alt" style="height:0" data-h="20%" title="Eólica: 1,900 GWh"></div><div class="chart-bar-lbl">Eólica</div></div>
              <div class="chart-bar-col"><div class="chart-bar alt" style="height:0" data-h="18%" title="Hidro: 1,740 GWh"></div><div class="chart-bar-lbl">Hidro</div></div>
              <div class="chart-bar-col"><div class="chart-bar" style="height:0" data-h="60%" title="GNL: 5,800 GWh"></div><div class="chart-bar-lbl">GNL</div></div>
              <div class="chart-bar-col"><div class="chart-bar alt" style="height:0" data-h="8%" title="Biomasa: 770 GWh"></div><div class="chart-bar-lbl">Biomasa</div></div>
            </div>
          </div>
          <div class="donut-card">
            <h3>Mix energético</h3>
            <div class="donut-wrap">
              <canvas id="donut-chart" width="140" height="140"></canvas>
              <div class="donut-center"><div class="val">100%</div><div class="lbl">Total</div></div>
            </div>
            <div class="donut-legend">
              <div class="legend-item"><span class="legend-dot" style="background:#1a6b3c"></span><span class="legend-label">Térmica</span><span class="legend-pct">56%</span></div>
              <div class="legend-item"><span class="legend-dot" style="background:#3db870"></span><span class="legend-label">GNL</span><span class="legend-pct">16%</span></div>
              <div class="legend-item"><span class="legend-dot" style="background:#4ade80"></span><span class="legend-label">Solar</span><span class="legend-pct">14%</span></div>
              <div class="legend-item"><span class="legend-dot" style="background:#06b6d4"></span><span class="legend-label">Eólica</span><span class="legend-pct">8%</span></div>
              <div class="legend-item"><span class="legend-dot" style="background:#0e7490"></span><span class="legend-label">Hidro</span><span class="legend-pct">6%</span></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}
