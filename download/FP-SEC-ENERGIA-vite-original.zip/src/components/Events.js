/**
 * Events — Agenda institucional con calendario y listado de eventos
 */
export function renderEvents() {
  return `
    <section id="events">
      <div class="section-inner">
        <div class="section-header fade-up">
          <div class="section-label">Agenda institucional</div>
          <h2 class="section-title">Eventos y agenda</h2>
        </div>
        <div class="events-layout fade-up">
          <div>
            <div class="calendar-mini">
              <div class="cal-header">
                <button class="cal-nav">‹</button>
                <span class="cal-month">Enero 2025</span>
                <button class="cal-nav">›</button>
              </div>
              <div class="cal-grid">
                <div class="cal-day-head">L</div><div class="cal-day-head">M</div><div class="cal-day-head">X</div><div class="cal-day-head">J</div><div class="cal-day-head">V</div><div class="cal-day-head">S</div><div class="cal-day-head">D</div>
                <div class="cal-day other-month">30</div><div class="cal-day other-month">31</div><div class="cal-day">1</div><div class="cal-day">2</div><div class="cal-day">3</div><div class="cal-day">4</div><div class="cal-day">5</div>
                <div class="cal-day">6</div><div class="cal-day">7</div><div class="cal-day has-event">8</div><div class="cal-day">9</div><div class="cal-day">10</div><div class="cal-day">11</div><div class="cal-day">12</div>
                <div class="cal-day">13</div><div class="cal-day">14</div><div class="cal-day today">15</div><div class="cal-day has-event">16</div><div class="cal-day">17</div><div class="cal-day">18</div><div class="cal-day">19</div>
                <div class="cal-day">20</div><div class="cal-day">21</div><div class="cal-day has-event">22</div><div class="cal-day">23</div><div class="cal-day">24</div><div class="cal-day">25</div><div class="cal-day">26</div>
                <div class="cal-day">27</div><div class="cal-day has-event">28</div><div class="cal-day">29</div><div class="cal-day">30</div><div class="cal-day">31</div><div class="cal-day other-month">1</div><div class="cal-day other-month">2</div>
              </div>
            </div>
          </div>
          <div class="events-list">
            <div class="event-card">
              <div class="event-date-badge"><div class="day">16</div><div class="mon">ENE</div></div>
              <div class="event-body">
                <h4>Foro Nacional: Transición Energética Justa en la República Dominicana</h4>
                <p>Espacio de diálogo multisectorial para analizar los retos y oportunidades de la transición energética con enfoque en empleo, equidad y desarrollo regional.</p>
                <div class="event-tags">
                  <span class="event-tag">Foro</span>
                  <span class="event-tag">Presencial</span>
                  <span class="event-tag loc">📍 Hotel Jaragua, Santo Domingo</span>
                </div>
              </div>
            </div>
            <div class="event-card">
              <div class="event-date-badge"><div class="day">22</div><div class="mon">ENE</div></div>
              <div class="event-body">
                <h4>Conferencia: Almacenamiento de Energía y Redes Inteligentes</h4>
                <p>Seminario técnico con expertos internacionales sobre baterías de gran escala, gestión de demanda y digitalización del sistema eléctrico.</p>
                <div class="event-tags">
                  <span class="event-tag">Conferencia</span>
                  <span class="event-tag">Híbrido</span>
                  <span class="event-tag loc">📍 PUCMM, Santiago</span>
                </div>
              </div>
            </div>
            <div class="event-card">
              <div class="event-date-badge"><div class="day">28</div><div class="mon">ENE</div></div>
              <div class="event-body">
                <h4>Rueda de prensa: Presentación del Informe de Pérdidas Eléctricas 2024</h4>
                <p>La Secretaría presenta públicamente los resultados del estudio sobre pérdidas técnicas y no técnicas en el sistema de distribución nacional.</p>
                <div class="event-tags">
                  <span class="event-tag">Prensa</span>
                  <span class="event-tag">Virtual</span>
                  <span class="event-tag loc">📍 Online · Zoom</span>
                </div>
              </div>
            </div>
            <div class="event-card">
              <div class="event-date-badge" style="background:var(--green-accent)"><div class="day">05</div><div class="mon">FEB</div></div>
              <div class="event-body">
                <h4>Cumbre Energética Fuerza del Pueblo 2025</h4>
                <p>Evento anual de la Secretaría de Energía con la participación de técnicos, legisladores, empresarios y sociedad civil en un diálogo estratégico de alto nivel.</p>
                <div class="event-tags">
                  <span class="event-tag">Cumbre</span>
                  <span class="event-tag">Presencial</span>
                  <span class="event-tag loc">📍 Centro de los Héroes, SD</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}
