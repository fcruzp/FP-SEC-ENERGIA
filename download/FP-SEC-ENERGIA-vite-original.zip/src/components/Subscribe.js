/**
 * Subscribe — Formulario de contacto, boletín y redes sociales
 */
export function renderSubscribe() {
  return `
    <section id="subscribe">
      <div class="section-inner">
        <div class="section-header centered fade-up">
          <div class="section-label">Mantente informado</div>
          <h2 class="section-title">Suscríbete y contáctanos</h2>
          <p class="section-desc">Recibe análisis, informes y comunicados directamente en tu correo. También puedes escribirnos.</p>
        </div>
        <div class="subscribe-grid">
          <div class="subscribe-left fade-up">
            <div class="subscribe-form">
              <h3 style="font-size:1.1rem;font-weight:700;color:var(--graphite);margin-bottom:24px;">Envíanos un mensaje</h3>
              <div class="form-row">
                <div class="form-group"><label>Nombre</label><input type="text" placeholder="Su nombre"/></div>
                <div class="form-group"><label>Apellido</label><input type="text" placeholder="Su apellido"/></div>
              </div>
              <div class="form-group"><label>Correo electrónico</label><input type="email" placeholder="correo@ejemplo.com"/></div>
              <div class="form-group">
                <label>Institución / Organización</label>
                <input type="text" placeholder="Nombre de su institución (opcional)"/>
              </div>
              <div class="form-group">
                <label>Tema</label>
                <select><option>Seleccione un tema...</option><option>Energías renovables</option><option>Tarifas eléctricas</option><option>Infraestructura</option><option>Prensa y medios</option><option>Otro</option></select>
              </div>
              <div class="form-group"><label>Mensaje</label><textarea placeholder="Escriba su mensaje aquí..."></textarea></div>
              <button class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Enviar mensaje →</button>
            </div>
          </div>
          <div class="subscribe-right fade-up">
            <div style="background:var(--green-deep);border-radius:var(--radius-lg);padding:36px;margin-bottom:24px;">
              <h3 style="font-size:1.1rem;font-weight:700;color:white;margin-bottom:8px;">Suscripción al boletín</h3>
              <p style="font-size:13px;color:rgba(255,255,255,0.6);line-height:1.7;margin-bottom:24px;">Análisis semanales, informes técnicos y comunicados oficiales de la Secretaría de Energía.</p>
              <div style="display:flex;gap:10px;">
                <input type="email" placeholder="Tu correo electrónico" style="flex:1;padding:12px 16px;border-radius:10px;border:1.5px solid rgba(255,255,255,0.15);background:rgba(255,255,255,0.08);color:white;font-family:var(--font-main);font-size:13px;outline:none;"/>
                <button class="btn btn-primary" style="white-space:nowrap">Suscribirse</button>
              </div>
            </div>
            <div class="socials-grid">
              <a class="social-card" href="#">
                <div class="si" style="background:rgba(29,161,242,0.1)">𝕏</div>
                <div><div class="sn">Twitter / X</div><div class="sh">@fpueblo_energia</div></div>
              </a>
              <a class="social-card" href="#">
                <div class="si" style="background:rgba(24,119,242,0.1)">f</div>
                <div><div class="sn">Facebook</div><div class="sh">FuerzaDelPuebloRD</div></div>
              </a>
              <a class="social-card" href="#">
                <div class="si" style="background:rgba(225,48,108,0.1)">📸</div>
                <div><div class="sn">Instagram</div><div class="sh">@fp.energia</div></div>
              </a>
              <a class="social-card" href="#">
                <div class="si" style="background:rgba(255,0,0,0.08)">▶</div>
                <div><div class="sn">YouTube</div><div class="sh">SecEnergíaFP</div></div>
              </a>
            </div>
            <div style="margin-top:24px;padding:24px;background:var(--gray-border);border-radius:var(--radius);">
              <h4 style="font-size:13px;font-weight:700;color:var(--graphite);margin-bottom:8px;">📍 Contacto directo</h4>
              <p style="font-size:12px;color:var(--gray-mid);line-height:1.8;">
                Av. Abraham Lincoln, esq. Gustavo Mejía Ricart,<br/>
                Torre FP, Piso 8, Santo Domingo, D.N.<br/>
                📞 (809) 000-0000<br/>
                ✉️ energia@fuerzadelpueblo.org.do
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}
