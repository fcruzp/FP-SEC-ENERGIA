/**
 * Leadership — Equipo directivo de la Secretaría
 */
export function renderLeadership() {
  return `
    <section id="leadership">
      <div class="section-inner">
        <div class="section-header centered fade-up">
          <div class="section-label">Equipo directivo</div>
          <h2 class="section-title">Titular y equipo técnico</h2>
          <p class="section-desc">Profesionales especializados en política energética, ingeniería de sistemas eléctricos, economía y sostenibilidad ambiental.</p>
        </div>
        <div class="team-grid">
          <div class="team-card fade-up">
            <div class="team-card-photo" style="background:linear-gradient(135deg,#0a2e19,#1a6b3c)">
              <div class="initials">JR</div>
              <span class="team-badge">Titular</span>
            </div>
            <div class="team-card-body">
              <h3>Dr. José Ramírez</h3>
              <div class="pos">Secretario de Energía</div>
              <p>Doctor en Ingeniería Eléctrica con más de 20 años de experiencia en política energética regional. Ex-director de la CDEEE y consultor de organismos multilaterales en materia de transición energética.</p>
            </div>
            <div class="team-card-footer">
              <a class="social-btn" href="#" title="LinkedIn">💼</a>
              <a class="social-btn" href="#" title="Twitter">🐦</a>
              <a class="social-btn" href="#" title="Email">✉️</a>
            </div>
          </div>
          <div class="team-card fade-up">
            <div class="team-card-photo" style="background:linear-gradient(135deg,#0f4526,#2d9e5f)">
              <div class="initials">MA</div>
              <span class="team-badge">Directora técnica</span>
            </div>
            <div class="team-card-body">
              <h3>Ing. María Alonzo</h3>
              <div class="pos">Directora de Energías Renovables</div>
              <p>Especialista en sistemas fotovoltaicos y eólicos. Máster en Energías Renovables por la Universidad de Chile. Autora de múltiples estudios sobre potencial solar dominicano.</p>
            </div>
            <div class="team-card-footer">
              <a class="social-btn" href="#" title="LinkedIn">💼</a>
              <a class="social-btn" href="#" title="Twitter">🐦</a>
              <a class="social-btn" href="#" title="Email">✉️</a>
            </div>
          </div>
          <div class="team-card fade-up">
            <div class="team-card-photo" style="background:linear-gradient(135deg,#134e2a,#3db870)">
              <div class="initials">CP</div>
              <span class="team-badge">Economista</span>
            </div>
            <div class="team-card-body">
              <h3>Lic. Carlos Pimentel</h3>
              <div class="pos">Director de Política Tarifaria</div>
              <p>Economista energético con especialización en regulación de mercados eléctricos. Investigador asociado al INTEC y consultor del Banco Interamericano de Desarrollo.</p>
            </div>
            <div class="team-card-footer">
              <a class="social-btn" href="#" title="LinkedIn">💼</a>
              <a class="social-btn" href="#" title="Twitter">🐦</a>
              <a class="social-btn" href="#" title="Email">✉️</a>
            </div>
          </div>
          <div class="team-card fade-up">
            <div class="team-card-photo" style="background:linear-gradient(135deg,#0a2e19,#2d9e5f)">
              <div class="initials">LG</div>
              <span class="team-badge">Analista</span>
            </div>
            <div class="team-card-body">
              <h3>Dra. Laura Guerrero</h3>
              <div class="pos">Directora de Sostenibilidad</div>
              <p>Doctora en Ciencias Ambientales con enfoque en transición energética justa. Experta en financiamiento climático y mecanismos de carbono para economías emergentes.</p>
            </div>
            <div class="team-card-footer">
              <a class="social-btn" href="#" title="LinkedIn">💼</a>
              <a class="social-btn" href="#" title="Twitter">🐦</a>
              <a class="social-btn" href="#" title="Email">✉️</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}
