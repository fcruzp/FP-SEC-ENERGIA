/**
 * About — Sección institucional con modelo 3D y misión/visión
 */
export function renderAbout() {
  return `
    <section id="about">
      <div class="section-inner">
        <div class="about-grid">
          <div class="about-visual fade-up">
            <div class="about-3d-container" style="position:relative;overflow:hidden;border-radius:24px;aspect-ratio:1;background:#0a2e19;">
              <!-- Sketchfab Power Storage Container Scene -->
              <iframe
                id="about-sketchfab-iframe"
                title="Power Storage Container Scene – Infraestructura energética"
                allow="autoplay; fullscreen; xr-spatial-tracking"
                src="https://sketchfab.com/models/a15a78b13272455baf25af252102cd8f/embed?autostart=1&ui_infos=0&ui_controls=0&ui_stop=0&ui_watermark=0&ui_watermark_link=0&ui_ar=0&ui_help=0&ui_settings=0&ui_vr=0&ui_fullscreen=0&ui_annotations=0&preload=1&camera=0&transparent=0&dnt=1&autospin=0.25&scrollwheel=0&double_click=0&ui_theme=dark&shading=lit"
                style="width:100%;height:100%;border:none;position:absolute;inset:0;opacity:0;transition:opacity 1.2s ease 0.8s;"
              ></iframe>
              <!-- Gradient masks to blend with section background -->
              <div style="position:absolute;inset:0;z-index:2;pointer-events:none;background:
                linear-gradient(to bottom, rgba(10,46,25,0.55) 0%, transparent 22%, transparent 78%, rgba(10,46,25,0.65) 100%),
                linear-gradient(to right, transparent 70%, rgba(244,246,244,0.18) 100%);
              "></div>
              <!-- Top-left institutional label -->
              <div id="about-model-badge" style="
                position:absolute;top:18px;left:18px;z-index:3;
                display:flex;align-items:center;gap:8px;
                background:rgba(10,46,25,0.78);backdrop-filter:blur(10px);
                border:1px solid rgba(74,222,128,0.22);border-radius:100px;
                padding:7px 14px;opacity:0;transition:opacity 0.7s ease 1.8s;pointer-events:none;
              ">
                <span style="width:7px;height:7px;border-radius:50%;background:#4ade80;display:block;animation:pulse 2s infinite;"></span>
                <span style="font-size:10.5px;font-weight:600;color:rgba(255,255,255,0.78);letter-spacing:0.7px;">Visualización 3D · Infraestructura energética</span>
              </div>
            </div>
            <div class="about-card-float">
              <div class="label">Fundada en</div>
              <div class="val">2023</div>
              <div class="sub">Bajo la dirección del Ing. Leonel</div>
            </div>
          </div>
          <div class="about-right fade-up">
            <div class="section-header">
              <div class="section-label">Sobre la Secretaría</div>
              <h2 class="section-title">Una institución para transformar el sector energético</h2>
              <p class="section-desc">
                La Secretaría de Energía de Fuerza del Pueblo es el organismo técnico-político responsable de formular, articular y difundir la visión energética del partido para la República Dominicana. Trabajamos con rigor académico, compromiso institucional y visión estratégica de largo plazo.
              </p>
            </div>
            <div class="mission-cards">
              <div class="mission-card">
                <div class="icon">🎯</div>
                <h4>Misión</h4>
                <p>Formular propuestas de política energética innovadoras, sostenibles y accesibles para todos los dominicanos.</p>
              </div>
              <div class="mission-card">
                <div class="icon">🔭</div>
                <h4>Visión</h4>
                <p>Una República Dominicana energéticamente soberana, limpia y competitiva para el año 2040.</p>
              </div>
              <div class="mission-card">
                <div class="icon">⚡</div>
                <h4>Objetivos estratégicos</h4>
                <p>Reducir pérdidas técnicas, democratizar el acceso, impulsar renovables y modernizar la infraestructura nacional.</p>
              </div>
              <div class="mission-card">
                <div class="icon">🏛️</div>
                <h4>Rol institucional</h4>
                <p>Somos el brazo técnico de Fuerza del Pueblo en materia energética, vinculando política y ciencia.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}
