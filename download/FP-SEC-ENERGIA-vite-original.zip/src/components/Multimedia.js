/**
 * Multimedia — Galería de videos y fotografías
 */
export function renderMultimedia() {
  return `
    <section id="multimedia">
      <div class="section-inner">
        <div class="section-header fade-up">
          <div class="section-label">Contenido multimedia</div>
          <h2 class="section-title">Galería multimedia</h2>
          <p class="section-desc">Entrevistas, foros, conferencias y fotografías del trabajo técnico y político de la Secretaría.</p>
        </div>
        <div class="gallery-grid fade-up">
          <div class="gallery-item">
            <div class="gallery-bg" style="background:linear-gradient(135deg,#0a2e19,#1a6b3c)">🎙️</div>
            <div class="gallery-overlay"></div>
            <div class="play-btn">▶</div>
            <div class="gallery-info">
              <div class="type">Video · Entrevista</div>
              <h4>Dr. Ramírez en CNN en Español: «La transformación energética de RD no puede esperar»</h4>
            </div>
          </div>
          <div class="gallery-item">
            <div class="gallery-bg" style="background:linear-gradient(135deg,#0f4526,#3db870)">🌞</div>
            <div class="gallery-overlay"></div>
            <div class="play-btn">▶</div>
            <div class="gallery-info">
              <div class="type">Video · Conferencia</div>
              <h4>Foro Solar RD 2024 — Resumen ejecutivo</h4>
            </div>
          </div>
          <div class="gallery-item">
            <div class="gallery-bg" style="background:linear-gradient(135deg,#134e2a,#2d9e5f)">📸</div>
            <div class="gallery-overlay"></div>
            <div class="gallery-info">
              <div class="type">Fotografía · Evento</div>
              <h4>Visita técnica a parque eólico Los Cocos</h4>
            </div>
          </div>
          <div class="gallery-item">
            <div class="gallery-bg" style="background:linear-gradient(135deg,#0e7490,#06b6d4)">⚡</div>
            <div class="gallery-overlay"></div>
            <div class="play-btn">▶</div>
            <div class="gallery-info">
              <div class="type">Video · Documental</div>
              <h4>Apagones en RD: causas, costos y soluciones</h4>
            </div>
          </div>
          <div class="gallery-item">
            <div class="gallery-bg" style="background:linear-gradient(135deg,#0a2e19,#4ade80)">🏗️</div>
            <div class="gallery-overlay"></div>
            <div class="gallery-info">
              <div class="type">Fotografía · Infraestructura</div>
              <h4>Inspección de subestaciones del norte del país</h4>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}
