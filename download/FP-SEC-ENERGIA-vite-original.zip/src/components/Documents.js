/**
 * Documents — Repositorio institucional de documentos y estudios
 */
export function renderDocuments() {
  return `
    <section id="documents">
      <div class="section-inner">
        <div class="section-header fade-up">
          <div class="section-label">Repositorio institucional</div>
          <h2 class="section-title">Documentos y estudios</h2>
          <p class="section-desc">Acceda a nuestros informes técnicos, propuestas de ley, estudios sectoriales y documentos de política pública.</p>
        </div>
        <div class="docs-toolbar fade-up">
          <div class="docs-types">
            <button class="filter-btn active">Todos</button>
            <button class="filter-btn">Informes</button>
            <button class="filter-btn">Propuestas</button>
            <button class="filter-btn">Estudios</button>
            <button class="filter-btn">Presentaciones</button>
          </div>
          <div class="docs-toggle">
            <button class="toggle-btn active">▦ Cuadrícula</button>
            <button class="toggle-btn">☰ Lista</button>
          </div>
        </div>
        <div class="docs-grid">
          <div class="doc-card fade-up">
            <div class="doc-header">
              <div class="doc-icon pdf">📄</div>
              <div><div class="doc-type-badge">PDF · INFORME</div><h4>Plan Estratégico de Transición Energética 2025–2035</h4></div>
            </div>
            <p>Hoja de ruta integral para la descarbonización progresiva de la matriz energética dominicana con metas, financiamiento y cronograma.</p>
            <div class="doc-footer">
              <span class="doc-date">📅 Enero 2025 · 84 págs.</span>
              <button class="doc-dl">⬇ Descargar</button>
            </div>
          </div>
          <div class="doc-card fade-up">
            <div class="doc-header">
              <div class="doc-icon pdf">📄</div>
              <div><div class="doc-type-badge">PDF · ESTUDIO</div><h4>Diagnóstico del Sistema Eléctrico Nacional 2024</h4></div>
            </div>
            <p>Evaluación técnica y financiera de las empresas distribuidoras, pérdidas, subsidios y calidad del servicio en todo el país.</p>
            <div class="doc-footer">
              <span class="doc-date">📅 Dic 2024 · 120 págs.</span>
              <button class="doc-dl">⬇ Descargar</button>
            </div>
          </div>
          <div class="doc-card fade-up">
            <div class="doc-header">
              <div class="doc-icon ppt">📊</div>
              <div><div class="doc-type-badge">PPT · PRESENTACIÓN</div><h4>Potencial Solar de la República Dominicana</h4></div>
            </div>
            <p>Mapeo geoespacial del recurso solar nacional con análisis de viabilidad técnica y económica por provincia y municipio.</p>
            <div class="doc-footer">
              <span class="doc-date">📅 Nov 2024 · 48 diapositivas</span>
              <button class="doc-dl">⬇ Descargar</button>
            </div>
          </div>
          <div class="doc-card fade-up">
            <div class="doc-header">
              <div class="doc-icon doc">📝</div>
              <div><div class="doc-type-badge">DOC · PROPUESTA</div><h4>Anteproyecto de Ley de Energías Renovables</h4></div>
            </div>
            <p>Propuesta legislativa completa que establece los incentivos, regulaciones y mecanismos de financiamiento para las energías limpias.</p>
            <div class="doc-footer">
              <span class="doc-date">📅 Oct 2024 · 36 págs.</span>
              <button class="doc-dl">⬇ Descargar</button>
            </div>
          </div>
          <div class="doc-card fade-up">
            <div class="doc-header">
              <div class="doc-icon pdf">📄</div>
              <div><div class="doc-type-badge">PDF · INFORME</div><h4>Análisis Tarifario Comparado: RD vs. Centroamérica</h4></div>
            </div>
            <p>Estudio comparativo de las estructuras tarifarias eléctricas de ocho países, con lecciones aplicables al mercado dominicano.</p>
            <div class="doc-footer">
              <span class="doc-date">📅 Sep 2024 · 62 págs.</span>
              <button class="doc-dl">⬇ Descargar</button>
            </div>
          </div>
          <div class="doc-card fade-up">
            <div class="doc-header">
              <div class="doc-icon ppt">📊</div>
              <div><div class="doc-type-badge">PPT · INFORME</div><h4>Estado del Arte: Almacenamiento Energético en RD</h4></div>
            </div>
            <p>Revisión del estado actual de las tecnologías de almacenamiento de energía y su aplicabilidad en la red eléctrica nacional.</p>
            <div class="doc-footer">
              <span class="doc-date">📅 Ago 2024 · 40 págs.</span>
              <button class="doc-dl">⬇ Descargar</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}
