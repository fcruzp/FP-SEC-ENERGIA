/**
 * Areas — Líneas estratégicas de acción
 */
export function renderAreas() {
  return `
    <section id="areas">
      <div class="section-inner">
        <div class="section-header fade-up">
          <div class="section-label">Líneas estratégicas</div>
          <h2 class="section-title">Líneas de acción</h2>
          <p class="section-desc">Diez ejes que articulan nuestra agenda de transformación del sector eléctrico y energético nacional.</p>
        </div>
        <div class="areas-grid">
          <div class="area-card fade-up">
            <div class="num">01</div><div class="icon">⚡</div>
            <h3>Sistema eléctrico</h3>
            <p>Modernización integral de la red de transmisión y distribución con tecnologías de red inteligente.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">02</div><div class="icon">🌱</div>
            <h3>Energías renovables</h3>
            <p>Plan nacional de expansión solar, eólica, hidroeléctrica y de biogás con metas claras al 2035.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">03</div><div class="icon">💰</div>
            <h3>Tarifas eléctricas</h3>
            <p>Reforma tarifaria que protege al consumidor residencial y garantiza la viabilidad financiera del sector.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">04</div><div class="icon">🛡️</div>
            <h3>Seguridad energética</h3>
            <p>Diversificación de fuentes y reducción de la dependencia de combustibles fósiles importados.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">05</div><div class="icon">🏗️</div>
            <h3>Infraestructura energética</h3>
            <p>Inversión estratégica en subestaciones, líneas de transmisión y terminales de GNL.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">06</div><div class="icon">🌍</div>
            <h3>Sostenibilidad</h3>
            <p>Alineación con el Acuerdo de París y los Objetivos de Desarrollo Sostenible de la ONU.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">07</div><div class="icon">📉</div>
            <h3>Pérdidas eléctricas</h3>
            <p>Estrategia integral para reducir las pérdidas técnicas y no técnicas al 15% en cinco años.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">08</div><div class="icon">🔬</div>
            <h3>Innovación energética</h3>
            <p>Fomento de I+D, startups energéticas y alianzas con universidades nacionales e internacionales.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">09</div><div class="icon">📊</div>
            <h3>Planificación estratégica</h3>
            <p>Plan Decenal de Energía con horizonte al 2035 basado en datos, modelos y consenso sectorial.</p>
            <div class="arrow">→</div>
          </div>
          <div class="area-card fade-up">
            <div class="num">10</div><div class="icon">🔄</div>
            <h3>Transición energética</h3>
            <p>Hoja de ruta hacia una economía baja en carbono que preserve empleos y dinamice el desarrollo.</p>
            <div class="arrow">→</div>
          </div>
        </div>
      </div>
    </section>
  `;
}
