/**
 * Hero — Sección principal con fondo Three.js y modelo 3D Sketchfab
 */
export function renderHero() {
  return `
    <section id="hero">
      <canvas id="hero-canvas"></canvas>
      <div class="hero-overlay"></div>

      <!-- Sketchfab Thermal Power Plant 3D Model -->
      <div class="hero-model-wrap" id="heroModelWrap">
        <iframe
          id="sketchfab-iframe"
          title="Thermal Power Plant – Infraestructura energética"
          allow="autoplay; fullscreen; xr-spatial-tracking"
          src="https://sketchfab.com/models/b6cdd73f754a4d739ed40da287038e40/embed?autostart=1&ui_infos=0&ui_controls=0&ui_stop=0&ui_watermark=0&ui_watermark_link=0&ui_ar=0&ui_help=0&ui_settings=0&ui_vr=0&ui_fullscreen=0&ui_annotations=0&preload=1&camera=0&transparent=0&dnt=1&autospin=0.3&scrollwheel=0&double_click=0&ui_theme=dark&background=000000&shading=lit&annotations_visible=0&orbit_constraint_zoom_in=2&orbit_constraint_zoom_out=8"
        ></iframe>
        <div class="hero-model-mask"></div>
        <div class="hero-model-glow"></div>
        <div class="model-label" id="modelLabel">
          <div class="ml-dot"></div>
          <span>Infraestructura energética nacional · Visualización 3D</span>
        </div>
      </div>

      <div class="hero-content">
        <div class="hero-badge fade-up"><span class="dot"></span>Fuerza del Pueblo · Secretaría de Energía</div>
        <h1 class="hero-title fade-up">
          Secretaría de<br/><span class="accent">Energía</span>
        </h1>
        <p class="hero-subtitle fade-up">
          Propuestas, análisis y visión estratégica para el futuro energético de la República Dominicana.
        </p>
        <div class="hero-actions fade-up">
          <a href="#areas" class="btn btn-primary btn-large">Ver propuestas</a>
          <a href="#news" class="btn btn-ghost btn-large">Leer comunicados</a>
        </div>
      </div>

      <div class="hero-stats">
        <div class="hero-stat fade-up"><div class="val" data-count="40">0</div><div class="lbl">% Pérdidas eléctricas</div></div>
        <div class="hero-divider"></div>
        <div class="hero-stat fade-up"><div class="val" data-count="4200">0</div><div class="lbl">MW Capacidad instalada</div></div>
        <div class="hero-divider"></div>
        <div class="hero-stat fade-up"><div class="val" data-count="28">0</div><div class="lbl">% Energía renovable</div></div>
        <div class="hero-divider"></div>
        <div class="hero-stat fade-up"><div class="val" data-count="12">0</div><div class="lbl">Propuestas de ley</div></div>
      </div>

      <div class="scroll-indicator">
        <div class="scroll-line"></div>
        <span class="scroll-text">Scroll</span>
      </div>
    </section>
  `;
}
