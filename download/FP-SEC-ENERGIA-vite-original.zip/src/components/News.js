/**
 * News — Sala de prensa con filtros y noticias
 */
export function renderNews() {
  return `
    <section id="news">
      <div class="section-inner">
        <div class="section-header fade-up">
          <div class="section-label">Sala de prensa</div>
          <h2 class="section-title">Noticias y comunicados</h2>
        </div>
        <div class="news-filter fade-up">
          <button class="filter-btn active">Todos</button>
          <button class="filter-btn">Renovables</button>
          <button class="filter-btn">Tarifas</button>
          <button class="filter-btn">Política energética</button>
          <button class="filter-btn">Infraestructura</button>
          <button class="filter-btn">Comunicados</button>
          <div class="news-search">
            <input type="text" placeholder="Buscar noticias..."/>
            <button>🔍</button>
          </div>
        </div>
        <div class="news-layout fade-up">
          <div class="news-featured">
            <div class="news-featured-bg">☀️</div>
            <div class="news-featured-overlay"></div>
            <div class="news-featured-body">
              <div class="news-tag">✦ Destacado</div>
              <h2>Secretaría de Energía presenta plan de expansión solar para las regiones del Cibao y el Sur</h2>
              <p>El documento técnico propone instalar 500 MW de capacidad fotovoltaica distribuida en zonas rurales con alta irradiación solar, priorizando comunidades sin acceso estable.</p>
              <div class="news-meta">
                <span>📅 15 enero 2025</span>
                <span>⏱ 8 min de lectura</span>
                <span>👁 4,230 vistas</span>
              </div>
            </div>
          </div>
          <div class="news-list">
            <div class="news-card">
              <div class="news-card-icon">⚡</div>
              <div class="news-card-body">
                <div class="news-tag" style="margin-bottom:8px;display:inline-flex">Tarifas</div>
                <h4>Análisis: El impacto de los nuevos subsidios eléctricos en los hogares de bajos ingresos</h4>
                <p>Estudio comparativo con experiencias de México, Costa Rica y Colombia.</p>
                <div class="news-card-meta"><span>📅 12 ene 2025</span><span>⏱ 5 min</span></div>
              </div>
            </div>
            <div class="news-card">
              <div class="news-card-icon">🌊</div>
              <div class="news-card-body">
                <div class="news-tag" style="margin-bottom:8px;display:inline-flex">Infraestructura</div>
                <h4>Secretaría evalúa potencial hidroeléctrico del río Yaque del Norte con nuevo levantamiento técnico</h4>
                <p>El estudio fue desarrollado junto al Instituto Geográfico Nacional y el IDIAF.</p>
                <div class="news-card-meta"><span>📅 8 ene 2025</span><span>⏱ 4 min</span></div>
              </div>
            </div>
            <div class="news-card">
              <div class="news-card-icon">📋</div>
              <div class="news-card-body">
                <div class="news-tag" style="margin-bottom:8px;display:inline-flex">Comunicado</div>
                <h4>Comunicado oficial: Posición de FP ante el nuevo reglamento de generación distribuida</h4>
                <p>La Secretaría exige que el marco regulatorio garantice la participación ciudadana.</p>
                <div class="news-card-meta"><span>📅 3 ene 2025</span><span>⏱ 3 min</span></div>
              </div>
            </div>
            <div class="news-card">
              <div class="news-card-icon">🌍</div>
              <div class="news-card-body">
                <div class="news-tag" style="margin-bottom:8px;display:inline-flex">Renovables</div>
                <h4>RD puede alcanzar el 50% de energía renovable antes de 2035 según nuevo informe</h4>
                <p>Análisis elaborado por el equipo técnico de la Secretaría con apoyo de IRENA.</p>
                <div class="news-card-meta"><span>📅 28 dic 2024</span><span>⏱ 6 min</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}
