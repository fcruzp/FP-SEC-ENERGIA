/**
 * MobileNav — Navegación móvil overlay
 */
export function renderMobileNav() {
  return `
    <div class="mobile-nav" id="mobileNav">
      <button class="mobile-nav-close" onclick="closeMobileNav()">✕</button>
      <a href="#hero" onclick="closeMobileNav()">Inicio</a>
      <a href="#about" onclick="closeMobileNav()">Sobre Nosotros</a>
      <a href="#observatory" onclick="closeMobileNav()">Observatorio</a>
      <a href="#news" onclick="closeMobileNav()">Noticias</a>
      <a href="#documents" onclick="closeMobileNav()">Documentos</a>
      <a href="#events" onclick="closeMobileNav()">Eventos</a>
      <a href="#multimedia" onclick="closeMobileNav()">Multimedia</a>
      <a href="#subscribe" onclick="closeMobileNav()">Contacto</a>
    </div>
  `;
}
