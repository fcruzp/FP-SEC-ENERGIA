/**
 * SiteHeader — Barra de navegación superior fija
 */
export function renderSiteHeader() {
  return `
    <header id="site-header" class="transparent">
      <div class="header-inner">
        <a class="logo-area" href="#hero">
          <div class="logo-badge">FP</div>
          <div class="logo-text">
            <div class="line1">Fuerza del Pueblo</div>
            <div class="line2">Secretaría de Energía</div>
          </div>
        </a>
        <nav class="main-nav">
          <a href="#hero">Inicio</a>
          <a href="#about">Sobre Nosotros</a>
          <a href="#observatory">Observatorio</a>
          <a href="#news">Noticias</a>
          <a href="#documents">Documentos</a>
          <a href="#events">Eventos</a>
          <a href="#multimedia">Multimedia</a>
          <a href="#subscribe">Contacto</a>
        </nav>
        <div class="header-cta">
          <a href="#news" class="btn btn-ghost">Comunicados</a>
          <a href="#subscribe" class="btn btn-primary">Suscribirse</a>
          <div class="hamburger" onclick="openMobileNav()">
            <span></span><span></span><span></span>
          </div>
        </div>
      </div>
    </header>
  `;
}
