/**
 * animations.js — Intersection Observer, fade-up, sketchfab embeds, filters
 */
import { initCounters } from './counters.js';
import { initDonutChart, initChartBars } from './charts.js';

// Intersection Observer for fade-up + counters + bars
export function initAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');

        // Trigger counters inside this element
        e.target.querySelectorAll('.counter').forEach(el => {
          const target = parseFloat(el.dataset.val);
          if (el.dataset.animated) return;
          el.dataset.animated = '1';
          const isFloat = String(target).includes('.');
          const duration = 1500;
          const start = performance.now();
          function update(now) {
            const progress = Math.min((now - start) / duration, 1);
            const ease = 1 - Math.pow(1 - progress, 3);
            const val = target * ease;
            el.textContent = isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString();
            if (progress < 1) requestAnimationFrame(update);
          }
          requestAnimationFrame(update);
        });

        // Trigger hero counters
        e.target.querySelectorAll('[data-count]').forEach(el => {
          if (el.dataset.animated) return;
          el.dataset.animated = '1';
          const target = parseInt(el.dataset.count);
          const duration = 2000;
          const start = performance.now();
          function update(now) {
            const p = Math.min((now - start) / duration, 1);
            el.textContent = Math.floor(target * (1 - Math.pow(1 - p, 3))).toLocaleString();
            if (p < 1) requestAnimationFrame(update);
          }
          requestAnimationFrame(update);
        });

        // Trigger KPI bars
        e.target.querySelectorAll('.kpi-bar-fill').forEach(el => {
          el.style.width = el.dataset.pct + '%';
        });

        // Trigger chart bars
        if (e.target.querySelector('.chart-bar')) {
          initChartBars();
        }
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));

  // Stagger delays
  document.querySelectorAll('.fade-up').forEach((el, i) => {
    el.style.transitionDelay = (i % 4) * 0.08 + 's';
  });
}

// Sketchfab iframe fade-in (Hero)
export function initSketchfabEmbed() {
  const iframe = document.getElementById('sketchfab-iframe');
  const label = document.getElementById('modelLabel');
  if (!iframe) return;

  iframe.addEventListener('load', () => {
    setTimeout(() => {
      iframe.classList.add('loaded');
      if (label) label.classList.add('visible');
    }, 600);
  });

  // Fallback after 5s
  setTimeout(() => {
    iframe.classList.add('loaded');
    if (label) label.classList.add('visible');
  }, 5000);
}

// Sketchfab iframe fade-in (About)
export function initAboutSketchfab() {
  const iframe = document.getElementById('about-sketchfab-iframe');
  const badge = document.getElementById('about-model-badge');
  if (!iframe) return;

  function reveal() {
    iframe.style.opacity = '1';
    if (badge) badge.style.opacity = '1';
  }

  iframe.addEventListener('load', () => setTimeout(reveal, 700));
  setTimeout(reveal, 5500);
}

// Filter buttons (news & documents)
export function initFilters() {
  document.querySelectorAll('.news-filter .filter-btn, .docs-types .filter-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      this.closest('.news-filter, .docs-types').querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });

  document.querySelectorAll('.docs-toggle .toggle-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.docs-toggle .toggle-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });
}
