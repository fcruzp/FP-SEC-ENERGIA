/**
 * header.js — Lógica del header: scroll, mobile nav
 */

// Mobile navigation
function openMobileNav() {
  document.getElementById('mobileNav').classList.add('open');
}
function closeMobileNav() {
  document.getElementById('mobileNav').classList.remove('open');
}

// Expose globally for inline onclick handlers
window.openMobileNav = openMobileNav;
window.closeMobileNav = closeMobileNav;

// Header scroll effect
export function initHeader() {
  const header = document.getElementById('site-header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 60) {
      header.classList.remove('transparent');
      header.classList.add('solid');
    } else {
      header.classList.add('transparent');
      header.classList.remove('solid');
    }
  });

  header.classList.add('transparent');
}
