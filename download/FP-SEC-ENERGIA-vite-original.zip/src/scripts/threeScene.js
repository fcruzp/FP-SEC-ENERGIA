/**
 * threeScene.js — Escena 3D del hero con Three.js
 */

export function initThreeScene() {
  const canvas = document.getElementById('hero-canvas');
  if (!canvas || typeof THREE === 'undefined') return;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(canvas.offsetWidth, canvas.offsetHeight);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, canvas.offsetWidth / canvas.offsetHeight, 0.1, 1000);
  camera.position.set(0, 0, 28);

  // Grid
  const gridGeo = new THREE.BufferGeometry();
  const gridVerts = [];
  const SIZE = 40, STEP = 3;
  for (let i = -SIZE; i <= SIZE; i += STEP) {
    gridVerts.push(-SIZE, 0, i, SIZE, 0, i);
    gridVerts.push(i, 0, -SIZE, i, 0, SIZE);
  }
  gridGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(gridVerts), 3));
  const gridMat = new THREE.LineBasicMaterial({ color: 0x1a6b3c, transparent: true, opacity: 0.18 });
  const grid = new THREE.LineSegments(gridGeo, gridMat);
  grid.rotation.x = Math.PI / 2;
  grid.position.z = -8;
  scene.add(grid);

  // Floating nodes
  const nodeMat = new THREE.MeshBasicMaterial({ color: 0x3db870, transparent: true, opacity: 0.85 });
  const nodes = [];
  for (let i = 0; i < 32; i++) {
    const geo = new THREE.SphereGeometry(0.12 + Math.random() * 0.18, 8, 8);
    const m = new THREE.Mesh(geo, nodeMat.clone());
    m.position.set(
      (Math.random() - 0.5) * 40,
      (Math.random() - 0.5) * 22,
      (Math.random() - 0.5) * 14 - 4
    );
    m.userData = {
      ox: m.position.x, oy: m.position.y, oz: m.position.z,
      speed: 0.3 + Math.random() * 0.5,
      phase: Math.random() * Math.PI * 2
    };
    scene.add(m);
    nodes.push(m);
  }

  // Connection lines
  const lineMat = new THREE.LineBasicMaterial({ color: 0x2d9e5f, transparent: true, opacity: 0.25 });
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const d = nodes[i].position.distanceTo(nodes[j].position);
      if (d < 10) {
        const lg = new THREE.BufferGeometry().setFromPoints([nodes[i].position, nodes[j].position]);
        scene.add(new THREE.Line(lg, lineMat));
      }
    }
  }

  // Particles
  const partGeo = new THREE.BufferGeometry();
  const pCount = 300;
  const pPos = new Float32Array(pCount * 3);
  for (let i = 0; i < pCount * 3; i++) pPos[i] = (Math.random() - 0.5) * 60;
  partGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
  const partMat = new THREE.PointsMaterial({ color: 0x4ade80, size: 0.08, transparent: true, opacity: 0.5 });
  const particles = new THREE.Points(partGeo, partMat);
  scene.add(particles);

  // Rings
  const ring1 = new THREE.Mesh(
    new THREE.TorusGeometry(6, 0.04, 8, 60),
    new THREE.MeshBasicMaterial({ color: 0x1a6b3c, transparent: true, opacity: 0.3 })
  );
  ring1.rotation.x = Math.PI / 3;
  ring1.position.set(8, 0, -6);
  scene.add(ring1);

  const ring2 = new THREE.Mesh(
    new THREE.TorusGeometry(4, 0.03, 8, 60),
    new THREE.MeshBasicMaterial({ color: 0x3db870, transparent: true, opacity: 0.2 })
  );
  ring2.rotation.x = -Math.PI / 4;
  ring2.position.set(-6, 2, -4);
  scene.add(ring2);

  // Mouse parallax
  let mx = 0, my = 0;
  window.addEventListener('mousemove', e => {
    mx = (e.clientX / window.innerWidth - 0.5) * 2;
    my = (e.clientY / window.innerHeight - 0.5) * 2;
  });

  // Animation loop
  let t = 0;
  function animate() {
    requestAnimationFrame(animate);
    t += 0.008;
    nodes.forEach(n => {
      n.position.y = n.userData.oy + Math.sin(t * n.userData.speed + n.userData.phase) * 1.2;
      n.position.x = n.userData.ox + Math.cos(t * n.userData.speed * 0.7 + n.userData.phase) * 0.5;
    });
    particles.rotation.y = t * 0.03;
    particles.rotation.x = t * 0.01;
    ring1.rotation.z = t * 0.4;
    ring2.rotation.z = -t * 0.3;
    grid.rotation.z = t * 0.015;
    camera.position.x += (mx * 2 - camera.position.x) * 0.03;
    camera.position.y += (-my * 1.5 - camera.position.y) * 0.03;
    camera.lookAt(0, 0, 0);
    renderer.render(scene, camera);
  }
  animate();

  // Resize handler
  window.addEventListener('resize', () => {
    const w = canvas.offsetWidth, h = canvas.offsetHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  });
}
