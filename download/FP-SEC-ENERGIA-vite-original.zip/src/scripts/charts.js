/**
 * charts.js — Gráfico donut del mix energético y barras de generación
 */

export function initDonutChart() {
  const canvas = document.getElementById('donut-chart');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const slices = [
    { pct: 0.56, color: '#1a6b3c' },
    { pct: 0.16, color: '#3db870' },
    { pct: 0.14, color: '#4ade80' },
    { pct: 0.08, color: '#06b6d4' },
    { pct: 0.06, color: '#0e7490' }
  ];
  const cx = 70, cy = 70, r = 55, inner = 36;
  let angle = -Math.PI / 2;

  ctx.clearRect(0, 0, 140, 140);
  slices.forEach(s => {
    const end = angle + s.pct * 2 * Math.PI;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, r, angle, end);
    ctx.closePath();
    ctx.fillStyle = s.color;
    ctx.fill();
    angle = end;
  });

  // Inner circle (donut hole)
  ctx.beginPath();
  ctx.arc(cx, cy, inner, 0, 2 * Math.PI);
  ctx.fillStyle = '#fff';
  ctx.fill();
}

export function initChartBars() {
  document.querySelectorAll('.chart-bar').forEach(bar => {
    setTimeout(() => { bar.style.height = bar.dataset.h; }, 200);
  });
}
