import { defineConfig } from 'vite';

export default defineConfig({
  root: '/home/z/my-project/FP-SEC-ENERGIA',
  build: {
    outDir: 'dist',
  }
});
